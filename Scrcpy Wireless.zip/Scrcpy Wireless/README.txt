Using Scrcpy Normally...

Instructions:
1. Move the Scrcpy Folder to disk "C"
* disk C for example
2. Go to This Pc
3. Right Click then Properties
4. Click Environmental Variables
5. Click Path
6. Add the path of Scrcpy.
7. Plug the Device to the PC
8. Enable USB debugging in the Developers Mode in the Device Settings
* To enable the Developers Mode, Go to About phone, Spam click the Version.

*Important Notice:

1. Edit Mirroring.bat 
2. Replace the text "your Device's Ip Address" with your Device's Ip Address
3. Save the changes.

 To use Scrcpy Wireless Totally...

Instructions:
*Initially Plugged
1. Open Command Prompt as  Administrator
2. Type "adb tcpip 5555"
3. Then type "adb connect "your Device's Ip Address"
*your Device's Ip address: example - 192.0.2.1
4. Unplug your device.
5. Run Scrcpy.bat

*Run Scrcpy.bat everytime you want to mirror your device.*